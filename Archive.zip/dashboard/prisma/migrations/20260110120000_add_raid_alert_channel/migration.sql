-- AlterTable
ALTER TABLE "Server" ADD COLUMN "raidAlertChannelId" TEXT;
