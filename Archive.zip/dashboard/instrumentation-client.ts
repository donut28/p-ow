// This file is intentionally empty
// PostHog initialization is now handled entirely in the PostHogProvider
// to ensure it only loads AFTER user consent is given
