
// Legacy file - re-exports EnsureConnections for backwards compatibility
// New code should import from ./ensure-connections

export { EnsureConnections, EnsureConnections as EnsureDiscordConnection } from "./ensure-connections"
