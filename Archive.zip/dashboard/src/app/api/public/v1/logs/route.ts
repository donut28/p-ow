import { prisma } from "@/lib/db"
import { validatePublicApiKey, findServerByName, logApiAccess } from "@/lib/public-auth"
import { NextResponse } from "next/server"

export async function GET(req: Request) {
    const auth = await validatePublicApiKey()
    if (!auth.valid) return NextResponse.json({ error: auth.error }, { status: auth.status || 401 })

    const { searchParams } = new URL(req.url)
    const serverName = searchParams.get("server")
    const type = searchParams.get("type")

    if (!serverName) return NextResponse.json({ error: "Missing server name" }, { status: 400 })

    const server = await findServerByName(serverName)
    if (!server) return NextResponse.json({ error: "Server not found" }, { status: 404 })

    try {
        const where: any = { serverId: server.id }
        if (type) where.type = type

        const logs = await prisma.log.findMany({
            where,
            orderBy: { createdAt: "desc" },
            take: 100
        })

        await logApiAccess(auth.apiKey, "PUBLIC_LOGS_COLLECTED", `Server: ${server.name}`)
        return NextResponse.json(logs)
    } catch (e) {
        console.error("Public Logs API Error:", e)
        return NextResponse.json({ error: "Internal Error" }, { status: 500 })
    }
}
